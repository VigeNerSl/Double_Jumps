const AUTHOR = "VigeNerSl";

import { 
    world, 
    system, 
    InputButton, 
    ButtonState 
} from "@minecraft/server";

const VigeNerSlMap = new Map();

function getVigeNerSL(player) {
    let VigeNerSi = VigeNerSlMap.get(player.id);
    if (!VigeNerSi) {
        VigeNerSi = {
            jumps: 0,
            used: false
        };
        VigeNerSlMap.set(player.id, VigeNerSi);
    }
    return VigeNerSi;
}

world.afterEvents.playerButtonInput.subscribe(vigenersl => {
    if (vigenersl.button !== InputButton.Jump) return;
    if (vigenersl.newButtonState !== ButtonState.Pressed) return;

    const VigeNerSl = vigenersl.player;
    const VigeNerSI = getVigeNerSL(VigeNerSl);

    VigeNerSI.jumps++;

    if (VigeNerSI.jumps !== 2 || VigeNerSI.used) return;

    const velocity = VigeNerSl.getVelocity();

    VigeNerSl.applyImpulse({
        x: 0,
        y: -velocity.y,
        z: 0
    });

    VigeNerSl.applyImpulse({
        x: 0,
        y: 0.65,
        z: 0
    });

    VigeNerSl.addEffect("slow_falling", 15, {
        amplifier: 0,
        showParticles: false
    });

    VigeNerSl.playSound("mob.enderdragon.flap", {
        volume: 0.3,
        pitch: 1.5
    });

    VigeNerSl.dimension.spawnParticle(
        "minecraft:critical_hit_emitter",
        VigeNerSl.location
    );

    VigeNerSI.used = true;
});

system.runInterval(() => {
    for (const VigeNerSl of world.getPlayers()) {
        if (!VigeNerSl.isOnGround) continue;
        
        const VigeNerSI = getVigeNerSL(VigeNerSl);
        VigeNerSI.jumps = 0;
        VigeNerSI.used = false;
    }
}, 2);