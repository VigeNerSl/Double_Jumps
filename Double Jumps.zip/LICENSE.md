Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)

Copyright © 2025-2026 VigeNerSl

You are free to:
- Share — copy and redistribute the material in any medium or format.
- Adapt — remix, transform, and build upon the material.

Under the following terms:
- Attribution (BY) — You must give appropriate credit, provide a link to the original work, and indicate if changes were made.
  Credit must clearly state: "Created by VigeNerSl".
- NonCommercial (NC) — You may not use the material for commercial purposes.
- ShareAlike (SA) — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

Full license text: https://creativecommons.org/licenses/by-nc-sa/4.0/