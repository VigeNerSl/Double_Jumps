import { world, system, InputButton, ButtonState } from "@minecraft/server";

const playerState = new Map();

world.afterEvents.playerButtonInput.subscribe((vigenersl) => {
  if (vigenersl.button !== InputButton.Jump) return;

  const player = vigenersl.player;
  const playerId = player.name;

  let state = playerState.get(playerId);
  if (!state) {
    state = { 
      hasDoubleJump: true, 
      lastJumpTick: -9999, 
      lastGroundTick: -9999 
    };
    playerState.set(playerId, state);
  }

  if (vigenersl.newButtonState !== ButtonState.Pressed) return;

  const currentTick = system.currentTick;
  const isOnGround = isPlayerGrounded(player);

  if (isOnGround) {
    state.lastGroundTick = currentTick;
    state.hasDoubleJump = true;
    return;
  }

  const ticksSinceGround = currentTick - state.lastGroundTick;
  const ticksSinceJump = currentTick - state.lastJumpTick;

  if (ticksSinceGround >= 3 && ticksSinceJump >= 8 && state.hasDoubleJump) {
    state.lastJumpTick = currentTick;
    state.hasDoubleJump = false;

    const velocity = player.getVelocity();
    const upwardImpulse = Math.max(0, 0.5 - Math.max(0, velocity.y));

    if (upwardImpulse > 0.01) {
      player.applyImpulse({ x: 0, y: upwardImpulse, z: 0 });
      player.addEffect("slow_falling", 10, { 
        amplifier: 0, 
        showParticles: false 
      });
    }
  }
});

system.runInterval(() => {
  for (const player of world.getPlayers()) {
    const velocity = player.getVelocity();
    
    if (velocity.y < 0) {
      const distanceToGround = getDistanceBelow(player);
      
      if (distanceToGround !== Infinity) {
        const isNearGround = distanceToGround <= Math.min(1.25, Math.max(0.45, -velocity.y * 0.3));
        
        if (isNearGround && velocity.y < -0.38) {
          const impulseNeeded = -0.38 - velocity.y;
          
          if (impulseNeeded > 0.005) {
            player.applyImpulse({ x: 0, y: impulseNeeded, z: 0 });
          }
        }
      }
    }
  }
}, 1);

function isPlayerGrounded(player) {
  const dimension = player.dimension;
  const location = player.location;
  
  const floorX = Math.floor(location.x);
  const floorZ = Math.floor(location.z);
  const checkY = Math.floor(location.y - 0.5);
  
  const heightRange = dimension.heightRange;
  const minY = heightRange?.min ?? -64;
  const maxY = heightRange?.max ?? 320;
  
  if (checkY < minY || checkY > maxY) return false;
  
  const isSolidBlock = (blockX, blockZ) => {
    if (checkY < minY || checkY > maxY) return false;
    
    const block = dimension.getBlock({ x: blockX, y: checkY, z: blockZ });
    if (!block || block.isAir) return false;
    
    const blockId = block.typeId;
    if (!blockId) return false;
    
    if (blockId.includes("water") || blockId.includes("lava") || blockId.includes("bubble_column")) {
      return false;
    }
    
    if (blockId === "minecraft:ladder" || blockId === "minecraft:vine" || blockId === "minecraft:scaffolding") {
      return false;
    }
    
    return true;
  };
  
  return isSolidBlock(floorX, floorZ);
}

function getDistanceBelow(player) {
  const dimension = player.dimension;
  const location = player.location;
  
  const heightRange = dimension.heightRange;
  const minY = heightRange?.min ?? -64;
  
  const floorX = Math.floor(location.x);
  const floorZ = Math.floor(location.z);
  
  let accumulatedDistance = 0;
  
  for (let checkY = location.y - 0.2; accumulatedDistance <= 3; checkY -= 0.25, accumulatedDistance += 0.25) {
    const blockY = Math.floor(checkY);
    
    if (blockY < minY) break;
    
    const block = dimension.getBlock({ x: floorX, y: blockY, z: floorZ });
    if (!block || block.isAir) continue;
    
    const blockId = block.typeId;
    if (!blockId) continue;
    
    if (blockId.includes("water") || blockId.includes("lava") || blockId.includes("bubble_column")) {
      continue;
    }
    
    if (blockId === "minecraft:ladder" || blockId === "minecraft:vine" || blockId === "minecraft:scaffolding") {
      continue;
    }
    
    return accumulatedDistance;
  }
  
  return Infinity;
}